# pdp11-sim

DEV: sub and bne are given to us in lecture notes